import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
from scipy.stats import pearsonr


def t12_t1_moving_avg_strat(commodity_data_df, price_col, window_12M = 252, window_1M = 21, percent_differnce = .1):
    mov_avg = commodity_data_df.copy()
    mov_avg['12M MA'] = mov_avg[price_col].rolling(window_12M).mean()
    mov_avg['1M MA'] = mov_avg[price_col].rolling(window_1M).mean()
    mov_avg[price_col+' Position'] = (mov_avg['12M MA'] - mov_avg['1M MA']) / mov_avg['1M MA']
    return mov_avg[price_col+' Position'].values


index_data_df = pd.read_excel("Cleaned_Data_stripped.xlsx")
index_data_df = index_data_df.fillna(method='bfill')
index_names_list = index_data_df.columns[1:]

momentum_ranking_cols = []
for col in index_data_df.columns[1:]:
    index_data_df[col+' Position'] = t12_t1_moving_avg_strat(index_data_df, col, window_12M = 252, window_1M = 21, percent_differnce = .1)
    momentum_ranking_cols.append(col+' Position')

index_data_df[momentum_ranking_cols] = index_data_df[momentum_ranking_cols].rank(axis=1, method='min')

bottom_cut_off = 5
top_cut_off = len(index_names_list)-4
index_data_df[momentum_ranking_cols] = index_data_df[momentum_ranking_cols].applymap(
    lambda x: -1 if x < bottom_cut_off else (1 if x > top_cut_off else 0)
)
