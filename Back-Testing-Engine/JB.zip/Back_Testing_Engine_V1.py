import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math
import warnings
warnings.filterwarnings('ignore')


def Back_Tester(df, fwd_daily_return_col, position_col):
    """
    Assumptions:
    Daily Close data
    The position column is the assuming we got filled at the closing price on that day, T.
    So the return needs to be calculated from T to T+1.

    Example:
    1/1/2000:
    Closing Price: 100
    Position: 1
    Return: 0%
    1/2/2000:
    Closing Price: 101
    Position: 1
    Return: 1%

    Position Types:
        1: Long
        0: Not Holding
       -1: Short
    """
    copy_df = df.copy()
    copy_df['Position Scaled Return'] = 1+(copy_df[fwd_daily_return_col] * copy_df[position_col])
    copy_df['Strategy Total Return'] = copy_df['Position Scaled Return'].cumprod()-1
    return copy_df


def calculate_bollinger_bands(df,price_col, window_size=20, num_std_dev=2):
    # Calculate the rolling mean and standard deviation
    copy_df = df.copy()
    copy_df['Rolling Mean'] = copy_df[price_col].rolling(window=window_size).mean()
    copy_df['Upper Band'] = copy_df['Rolling Mean'] + (copy_df[price_col].rolling(window=window_size).std() * num_std_dev)
    copy_df['Lower Band'] = copy_df['Rolling Mean'] - (copy_df[price_col].rolling(window=window_size).std() * num_std_dev)

    return copy_df

def find_first_date(df):
    return df.dropna()['Date'].min()

"""
Loading testing data
"""
index_prices_df_header = pd.read_csv("Testing_Future_Data.csv")
index_prices_df = index_prices_df_header.iloc[1:]
index_prices_df['Date'] = pd.to_datetime(index_prices_df['Date'])
index_prices_df.sort_values(by='Date',inplace=True)
index_prices_df.iloc[:,1:] = index_prices_df.iloc[:,1:].astype(float)


"""
Cleaning individual commodity index
Creating dictionary of dataframes structure
"""
list_of_index_names = index_prices_df_header.columns[1:]
Commodity_Data_Master = {}

for i in list_of_index_names:
    temp_df = index_prices_df[['Date',i]]
    temp_df = temp_df[temp_df['Date'] > find_first_date(temp_df)]
    temp_df = temp_df.fillna(method='bfill').dropna()
    temp_df.reset_index(inplace=True)
    temp_df.drop("index",axis=1,inplace=True)

    temp_df[i+" Daily Return"] = temp_df[i].pct_change()
    temp_df[i+" FWD Daily Return"] = np.nan
    temp_df[i+" FWD Daily Return"].iloc[:-1] = temp_df[i+" Daily Return"].iloc[1:]
    Commodity_Data_Master[i] = temp_df


print("  ")
print(Commodity_Data_Master['Soybean'])
print("-------------------------------")
print(Commodity_Data_Master['Gold'])

Soybean_df = Commodity_Data_Master['Soybean']
Soybean_df = Soybean_df.iloc[1:]
Soybean_df.reset_index(inplace=True)
Soybean_df = Soybean_df.iloc[:,1:]

window_size = 21
Soybean_df = calculate_bollinger_bands(Soybean_df,'Soybean').iloc[window_size:]

Soybean_df['Position'] = 0
Soybean_df['Position'][Soybean_df['Soybean'] > Soybean_df['Upper Band']] = -1
Soybean_df['Position'][Soybean_df['Soybean'] < Soybean_df['Lower Band']] = 1

Soybean_df = Back_Tester(Soybean_df, 'Soybean FWD Daily Return', 'Position')
Soybean_df['Index TR'] = (1+Soybean_df['Soybean Daily Return']).cumprod()-1
print(Soybean_df)
plt.plot(Soybean_df['Date'], Soybean_df['Strategy Total Return'],label='Strategy Return')
plt.plot(Soybean_df['Date'], Soybean_df['Index TR'],label='Index Return')
plt.gca().set_yticklabels([f'{x:.0%}' for x in plt.gca().get_yticks()])
plt.legend()
plt.show()

























#
#
# window_size = 21
#
# bb_df = calculate_bollinger_bands(metals_df,'Copper').iloc[window_size:]
#
#
# bb_df['Position'] = 0
# bb_df['Position'][bb_df['Copper'] > bb_df['Upper Band']] = -1
# bb_df['Position'][bb_df['Copper'] < bb_df['Lower Band']] = 1



# bb_df = Back_Tester(bb_df, 'Copper FWD Daily Return', 'Position')
# bb_df['Index TR'] = (1+bb_df['Copper Daily Return']).cumprod()-1
# plt.plot(bb_df['Date'], bb_df['Strategy Total Return'],label='Strategy Return')
# plt.plot(bb_df['Date'], bb_df['Index TR'],label='Index Return')
# plt.legend()
# plt.show()















# bb_df['Position'] =
# plt.plot(bb_df['Date'],bb_df.iloc[:,-2:])
# plt.plot(bb_df['Date'],bb_df['Nickel'])
# plt.legend()
# plt.show()
# print(metals_df)

#Random Strat
# np.random.seed(14)

# nickel_df = metals_df[['Date','Nickel']]
# nickel_df['Position'] = 0
# for i in range(math.floor(len(nickel_df)/15)):
#     i = i*15
#     nickel_df['Position'].iloc[i:i+15] = np.random.choice([-1,0,1])
#
# nickel_df.reset_index(inplace=True)
# nickel_df = nickel_df.iloc[:,1:]
#
# #
# nickel_df['Index Total Return'] = (1+nickel_df['Nickel']).cumprod()-1
# plt.plot(nickel_df['Date'],nickel_df['Index Total Return'],label='Index Return',color='darkgreen')
# plt.plot(nickel_df['Date'],back_tester(nickel_df,'Nickel','Position')['Strategy Total Return'],label='Strategy Return',alpha=.2)
# # plt.legend()
# plt.show()


#
# print(nickel_df)
# #backtest
# #
# current_position = nickel_df['Position'].iloc[0]
#
# # current_position_index = [0]
# print(current_position)
# print(nickel_df)
#
# for i in range(len(nickel_df)):
#     if i == 0:
#         pass
#     else:
#         if nickel_df['Position'].iloc[i] == 0:
#             nickel_df['PnL'].iloc[i] = nickel_df['PnL'].iloc[i-1]
#             nickel_df['Total Return'].iloc[i] = nickel_df['Total Return'].iloc[i-1]
#
#         if nickel_df['Position'].iloc[i] == 1:
#             nickel_df['PnL'].iloc[i] = nickel_df['PnL'].iloc[i-1] * nickel_df['Total Return'].iloc[i-1]
#
#             nickel_df['Total Return'].iloc[i] = nickel_df['Total Return'].iloc[i-1]


    # if nickel_df['Position'].iloc[i] != current_position[-1]:
    #     current_position_index.append(i)
    #     current_position.append(nickel_df['Position'].iloc[i])



# for i in range(len(nickel_df)):
#     if nickel_df['Position'].iloc[i] != current_position[-1]:
#         current_position_index.append(i)
#         current_position.append(nickel_df['Position'].iloc[i])
#
# current_position_index.append(nickel_df.index[-1])





# print(current_position_index)
# print(current_position)



# last_PnL = init_PnL
# last_TR = 0
# for i in range(4):
#
#     temp_period = nickel_df.iloc[current_position_index[i] : current_position_index[i+1]]
#     # print(temp_period)
#
#
#     if temp_period['Position'].unique()[0] == 0:
#         temp_period['Total Return'] = last_TR
#         temp_period['PnL'] = last_PnL
#
#
#     elif temp_period['Position'].unique()[0] == 1:
#         for j in range(len(temp_period)):
#             if i == 0 and j == 0:
#                 last_TR = (1+last_TR)
#             temp_period['Total Return'].iloc[j] =  (last_TR)*(1+temp_period['Nickel'].iloc[0:j+1]).prod()
#             temp_period['PnL'] = temp_period['PnL'].iloc[0]*temp_period['Total Return']
#
#     # elif temp_period['Position'].unique()[0] == -1:
#     #     temp_period['Nickel'] *= -1
#     #     for j in range(len(temp_period)):
#     #         temp_period['Total Return'].iloc[j] = (1+temp_period['Nickel'].iloc[0:j+1]).prod()
#     #         temp_period['PnL'] = temp_period['PnL'].iloc[0]*temp_period['Total Return']
#
#
#
#
#     nickel_df.loc[temp_period.index] = temp_period
#     print(temp_period)
#     # print(current_position[i])
#     # print(temp_period['Nickel'].prod())
#     # print(temp_period.iloc[-1])
#     last_PnL = temp_period['PnL'].iloc[-1]
#     last_TR = temp_period['Total Return'].iloc[-1]
#
#
# print(nickel_df.head(30))

















##
