
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math
import warnings
import time
warnings.filterwarnings('ignore')

def Back_Tester(df, fwd_daily_return_col, position_col):
    """
    Assumptions:
    Daily Close data
    The position column is the assuming we got filled at the closing price on that day, T.
    So the return needs to be calculated from T to T+1.

    Example:
    1/1/2000:
    Closing Price: 100
    Position: 1
    Return: 0%
    1/2/2000:
    Closing Price: 101
    Position: 1
    Return: 1%

    Position Types:
        1: Long
        0: Not Holding
       -1: Short
    """
    copy_df = df.copy()
    copy_df['Position Scaled Return'] = 1+(copy_df[fwd_daily_return_col] * copy_df[position_col])
    copy_df['Strategy Total Return'] = copy_df['Position Scaled Return'].cumprod()-1
    return copy_df


def calculate_bollinger_bands(df,price_col, window_size=20, num_std_dev=2):
    # Calculate the rolling mean and standard deviation
    copy_df = df.copy()
    copy_df['Rolling Mean'] = copy_df[price_col].rolling(window=window_size).mean()
    copy_df['Upper Band'] = copy_df['Rolling Mean'] + (copy_df[price_col].rolling(window=window_size).std() * num_std_dev)
    copy_df['Lower Band'] = copy_df['Rolling Mean'] - (copy_df[price_col].rolling(window=window_size).std() * num_std_dev)

    return copy_df

def find_first_date(df):
    return df.dropna()['Date'].min()


"""
Loading testing data
"""
index_prices_df_header = pd.read_csv("Testing_Future_Data.csv")
index_prices_df = index_prices_df_header.iloc[1:]
index_prices_df['Date'] = pd.to_datetime(index_prices_df['Date'])
index_prices_df.sort_values(by='Date',inplace=True)
index_prices_df.iloc[:,1:] = index_prices_df.iloc[:,1:].astype(float)
index_prices_df = index_prices_df[index_prices_df['Date'] > pd.to_datetime("12/31/2015")]
index_prices_df = index_prices_df[index_prices_df['Date'] < pd.to_datetime("12/31/2019")]
index_prices_df = index_prices_df.fillna(method='bfill').dropna()

weekly_df = pd.DataFrame()
for i in index_prices_df.columns[1:]:
    temp_series = 1+index_prices_df[i].pct_change()
    returns_array = []
    for j in range(math.floor(len(temp_series)/20)):
        j = j*20
        returns_array.append(temp_series.iloc[j:j+20].prod())
    weekly_df[i] = returns_array



weekly_df['Gold'] = weekly_df['Nickel']*-1
# weekly_df['Corn'] = weekly_df['Corn']*-1
# corr_df = weekly_df.corr()
# print(corr_df)

# corr_df['Nickel'] = corr_df['Nickel']*-1
# corr_df.loc['Nickel'] = corr_df.loc['Nickel']*-1
# print(corr_df)

corr_df = weekly_df.corr().to_numpy()
np.fill_diagonal(corr_df,0) #Set Diagonal to 0, since they = 1

#Baseline Equal Weighted Portfolio
weights = np.array([1/8]*8)
weights = (1/np.sum(weights))*weights #Scale to equal 1
weights_matrix = np.outer(weights, weights)

print("Equal Weighted Portfolio Correlation")
print(round(np.sum(corr_df*weights_matrix),5))
print()

start = time.time()
best_num = []
for j in range(100):

    best_weights = []
    best_port_correlation = 100
    for i in range(10000):
        weights_i = np.random.uniform(.03,.1,8) #Can easily set min/max constraints
        weights_i = (1/np.sum(weights_i))*weights_i
        weights_i_matrix = np.outer(weights_i, weights_i)
        total_port_correlation = np.sum(corr_df*weights_i_matrix)

        if abs(total_port_correlation) < best_port_correlation:
            best_port_correlation = total_port_correlation
            best_weights = weights_i

    # print("Optimized Weighted Portfolio Correlation")
    # print(round(best_port_correlation,5))
    best_num.append(best_port_correlation)
    # # print()
    # # print("Best Weights: ")
    # # print(best_weights)
    # stop = time.time()
    # duration = stop-start
    # print("50,000 Random Combos Time: ",duration)
stop = time.time()
duration = stop-start
print(duration)
plt.plot(best_num)
plt.show()
# index_prices_df.iloc[:,1:].pct_change().corr().to_csv("corr_matrix.csv")
# """
# Cleaning individual commodity index
# Creating dictionary of dataframes structure
# """
# list_of_index_names = index_prices_df_header.columns[1:]
# Commodity_Data_Master = {}
#
# for i in list_of_index_names:
#     temp_df = index_prices_df[['Date',i]]
#     temp_df = temp_df[temp_df['Date'] > find_first_date(temp_df)]
#     temp_df = temp_df.fillna(method='bfill').dropna()
#     temp_df.reset_index(inplace=True)
#     temp_df.drop("index",axis=1,inplace=True)
#
#     temp_df[i+" Daily Return"] = temp_df[i].pct_change()
#     temp_df[i+" FWD Daily Return"] = np.nan
#     temp_df[i+" FWD Daily Return"].iloc[:-1] = temp_df[i+" Daily Return"].iloc[1:]
#     Commodity_Data_Master[i] = temp_df
#
# returns_df = Commodity_Data_Master['Crude Oil Futures']
# returns_df.drop(['Crude Oil Futures','Crude Oil Futures FWD Daily Return'],axis=1,inplace=True)
# returns_df = returns_df[returns_df['Date'] > pd.to_datetime("12/31/2015")]
# returns_df = returns_df[returns_df['Date'] < pd.to_datetime("12/31/2019")]
# print(returns_df)
# for i in Commodity_Data_Master:
#     if i != 'Crude Oil Futures':
#         temp_df = Commodity_Data_Master[i]
#         temp_df = temp_df[temp_df['Date'] > pd.to_datetime("12/31/2015")]
#         temp_df = temp_df[temp_df['Date'] < pd.to_datetime("12/31/2019")]
#         returns_df[i] = temp_df[i+" Daily Return"]
# print(returns_df)
