import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
from scipy.stats import pearsonr


def Back_Tester(df, fwd_daily_return_col, position_col):
    """
    Assumptions:
    Daily Close data
    The position column is the assuming we got filled at the closing price on that day, T.
    So the return needs to be calculated from T to T+1.

    Example:
    1/1/2000:
    Closing Price: 100
    Position: 1
    Return: 0%
    1/2/2000:
    Closing Price: 101
    Position: 1
    Return: 1%

    Position Types:
        1: Long
        0: Not Holding
       -1: Short
    """
    copy_df = df.copy()
    copy_df['Position Scaled Return'] = 1+(copy_df[fwd_daily_return_col] * copy_df[position_col])
    copy_df['Strategy Total Return'] = copy_df['Position Scaled Return'].cumprod()-1
    return copy_df

def t12_t1_moving_avg_strat(commodity_data_df, price_col, window_12M = 252, window_1M = 21, percent_differnce = .1):
    mov_avg = commodity_data_df.copy()
    mov_avg['12M MA'] = mov_avg[price_col].rolling(window_12M).mean()
    mov_avg['1M MA'] = mov_avg[price_col].rolling(window_1M).mean()
    mov_avg[price_col+' Position'] = (mov_avg['12M MA'] - mov_avg['1M MA']) / mov_avg['1M MA']
    return mov_avg[price_col+' Position'].values


index_data_df = pd.read_excel("Cleaned_Data_stripped.xlsx")
index_data_df = index_data_df.fillna(method='bfill')
index_data_df.iloc[:,1:].pct_change().iloc[255:].to_csv("Daily_Returns_Slimmed.csv")

index_names_list = index_data_df.columns[1:]

momentum_ranking_cols = []
for col in index_data_df.columns[1:]:
    index_data_df[col+' Position'] = t12_t1_moving_avg_strat(index_data_df, col, window_12M = 252, window_1M = 21, percent_differnce = .1)
    momentum_ranking_cols.append(col+' Position')

index_data_df[momentum_ranking_cols] = index_data_df[momentum_ranking_cols].rank(axis=1, method='min')

bottom_cut_off = 5
top_cut_off = len(index_names_list)-4
print(len(index_names_list),bottom_cut_off,top_cut_off)
index_data_df[momentum_ranking_cols] = index_data_df[momentum_ranking_cols].applymap(
    lambda x: -1 if x < bottom_cut_off else (1 if x > top_cut_off else 0)
)



index_data_df = index_data_df.iloc[255:]


daily_returns_col = []
fwd_returns_cols = []
strategy_tr_cols = []
pos_returns_cols = []
position_col = []
for col in index_names_list:

    # index_data_df[col+" 12-1 MA"] = t12_t1_moving_avg_strat(index_data_df, col, window_12M = 252, window_1M = 21, percent_differnce = .1)
    index_data_df[col+" Daily Return"] = index_data_df[col].pct_change()
    index_data_df[col+" FWD Daily Return"] = np.nan
    index_data_df[col+" FWD Daily Return"].iloc[:-1] = index_data_df[col+" Daily Return"].iloc[1:]
    bb_df = Back_Tester(index_data_df, col+' FWD Daily Return', col+' Position')
    index_data_df[col+" Position Scaled Return"] = bb_df['Position Scaled Return']
    index_data_df[col+" Strategy Total Return"] = bb_df['Strategy Total Return']
    daily_returns_col.append(col+" Daily Return")
    fwd_returns_cols.append(col+" FWD Daily Return")
    strategy_tr_cols.append(col+" Strategy Total Return")
    pos_returns_cols.append(col+" Position Scaled Return")
    position_col.append(col+" Position")



index_data_df = index_data_df.iloc[1:-1]
covar_columns = daily_returns_col+position_col+pos_returns_cols
covar_columns.append("Date")
index_data_df[covar_columns].to_csv("covar_data.csv")

daily_fwd_returns_scaled = index_data_df[pos_returns_cols]-1
daily_fwd_returns_scaled.to_csv("Daily_Strategy_Returns.csv")
