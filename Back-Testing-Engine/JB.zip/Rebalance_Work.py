import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
from scipy.stats import pearsonr
from numba import jit, cuda

def generate_random_weight_combinations(num_weights, num_combinations):
    # Generate random weights that sum to 1
    weights_combinations = np.random.dirichlet(np.ones(num_weights), num_combinations)

    return weights_combinations
num_weights = 8
num_combinations = 100

weight_combinations = generate_random_weight_combinations(num_weights, num_combinations)

df = pd.read_csv("covar_data.csv")
df['Date'] = pd.to_datetime(df['Date'])
df = df.iloc[252:]
fwd_returns = df.iloc[:,-15:]-1
weighted_returns = []
for i in range(len(fwd_returns)):
    temp_series = fwd_returns.iloc[i][fwd_returns.iloc[i] != 0]
    if len(temp_series) != 0:
        temp_weights = np.array([1/len(temp_series)]*len(temp_series))
        weighted_returns.append(np.dot(temp_series,temp_weights))
    else:
        weighted_returns.append(0)

df['Equal Weights'] = weighted_returns
# df.to_csv("EQL_Weights.csv")
# plt.plot(df['Date'],(1+df['Equal Weights']).cumprod()-1,label='Equal Weights')
# copy_df['Strategy Total Return'] = copy_df['Position Scaled Return'].cumprod()-1
# print(df)


"""
Min Weights
"""
df = pd.read_csv("covar_data.csv")
df['Date'] = pd.to_datetime(df['Date'])
reg_return_columns = df.iloc[:,1:16].columns.values
position_columns = df.iloc[:,16:31].columns.values
pos_scaled_columns = df.iloc[:,-15:].columns.values

# print(df.iloc[0:0+252,1:16].corr().to_numpy())
fwd_returns_df = df[pos_scaled_columns]-1
position_df = df[position_columns]
covar_returns_df = df[reg_return_columns]

portfolio_correlation_ts = []
weighted_returns = []
dates = []
for i in range(len(df)-252):
# for i in range(20):
    # dates.append(df['Date'].iloc[i])
    i = 252+i
    dates.append(df['Date'].iloc[i])
    temp_position_series = position_df.iloc[i][position_df.iloc[i] != 0]
    temp_position_names = temp_position_series.index.values
    temp_covar_names = [x[:-9]+" Daily Return" for x in temp_position_names]
    temp_fwd_names = [x[:-9]+" Position Scaled Return" for x in temp_position_names]
    temp_fwd_series = fwd_returns_df[temp_fwd_names].iloc[i]

    temp_corr_df = covar_returns_df[temp_covar_names].iloc[i-252:i] *temp_position_series.values # Scaling correlation by direction L/S
    temp_corr_df = temp_corr_df*temp_position_series.values
    corr_df = temp_corr_df.corr().to_numpy()
    np.fill_diagonal(corr_df,0)
    best_weights = []
    best_port_correlation = 100

    if len(temp_fwd_series) != 0:
        for weights_i in weight_combinations:
            # weights_i = np.random.uniform(.03,.1,len(temp_position_series)) #Can easily set min/max constraints
            # weights_i = (1/np.sum(weights_i))*weights_i

            weights_i_matrix = np.outer(weights_i, weights_i)
            total_port_correlation = np.sum(corr_df*weights_i_matrix)

            if abs(total_port_correlation) < best_port_correlation:
                best_port_correlation = total_port_correlation
                best_weights = weights_i



        # temp_weights = np.array([1/len(temp_series)]*len(temp_series))
        portfolio_correlation_ts.append(best_port_correlation)
        weighted_returns.append(np.dot(temp_fwd_series,best_weights))
    else:
        weighted_returns.append(0)

# pd.DataFrame({"Date":dates,"Weighted Returns":weighted_returns}).to_csv("Weighted_Returns_N10000_03_10_dir.csv")
print(np.cumprod(1+np.array(weighted_returns))-1)

plt.plot(np.cumprod(1+np.array(weighted_returns))-1,label="Correlation Minimized")
# plt.legend()
plt.show()
#
plt.plot(portfolio_correlation_ts)
plt.show()





# df['Equal Weights'] = weighted_returns
# plt.plot((1+df['Equal Weights']).cumprod()-1)
# plt.show()
# # copy_df['Strategy Total Return'] = copy_df['Position Scaled Return'].cumprod()-1
# print(df)












#
