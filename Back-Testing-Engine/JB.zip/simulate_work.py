import numpy as np
from itertools import product

def generate_linear_weight_combinations(num_weights, num_combinations, weight_range=(0, 0.25)):
    # Generate combinations on the fly
    weights_combinations = np.array(list(product(*(np.linspace(weight_range[0], weight_range[1], num_combinations) for _ in range(num_weights)))))

    # Filter combinations that sum to 1
    valid_combinations = [weights for weights in weights_combinations if np.isclose(np.sum(weights), 1)]

    return valid_combinations

# Example usage:
num_weights = 8
num_combinations = 100
weight_range = (0, 0.25)

weight_combinations = generate_linear_weight_combinations(num_weights, num_combinations, weight_range)
