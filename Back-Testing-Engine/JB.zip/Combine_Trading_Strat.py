import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
from scipy.stats import pearsonr


def Back_Tester(df, fwd_daily_return_col, position_col):
    """
    Assumptions:
    Daily Close data
    The position column is the assuming we got filled at the closing price on that day, T.
    So the return needs to be calculated from T to T+1.

    Example:
    1/1/2000:
    Closing Price: 100
    Position: 1
    Return: 0%
    1/2/2000:
    Closing Price: 101
    Position: 1
    Return: 1%

    Position Types:
        1: Long
        0: Not Holding
       -1: Short
    """
    copy_df = df.copy()
    copy_df['Position Scaled Return'] = 1+(copy_df[fwd_daily_return_col] * copy_df[position_col])
    copy_df['Strategy Total Return'] = copy_df['Position Scaled Return'].cumprod()-1
    return copy_df

def t12_t1_moving_avg_strat(commodity_data_df, price_col, window_12M = 252, window_1M = 21, percent_differnce = .1):

    mov_avg = commodity_data_df.copy()
    mov_avg['12M MA'] = mov_avg[price_col].rolling(window_12M).mean()
    mov_avg['1M MA'] = mov_avg[price_col].rolling(window_1M).mean()
    mov_avg['12-1 MA'] = mov_avg['12M MA'] - mov_avg['1M MA']
    return mov_avg['12-1 MA'].values


def MACD_strat(commodity_data_df, price_col, short_window=12, long_window=26, signal_window=9):

    mcad_df = commodity_data_df.copy()
    mcad_df['Short_EMA'] = mcad_df[price_col].ewm(span=short_window, adjust=False).mean()
    mcad_df['Long_EMA'] = mcad_df[price_col].ewm(span=long_window, adjust=False).mean()
    mcad_df['MACD'] = mcad_df['Short_EMA'] - mcad_df['Long_EMA']
    mcad_df['Signal_Line'] = mcad_df['MACD'].ewm(span=signal_window, adjust=False).mean()

    mcad_df['Position'] = np.where((mcad_df['MACD'] > mcad_df['Signal_Line']) & (mcad_df['MACD'].shift(1) <= mcad_df['Signal_Line'].shift(1)), 1, 0)
    mcad_df['Position'] = np.where((mcad_df['MACD'] < mcad_df['Signal_Line']) & (mcad_df['MACD'].shift(1) >= mcad_df['Signal_Line'].shift(1) ), -1, mcad_df['Position'])

    clean_return_df = pd.DataFrame()
    clean_return_df['Date'] = mcad_df['Date']
    clean_return_df[price_col] = mcad_df[price_col]
    clean_return_df[price_col+' Position'] = mcad_df['Position']
    return clean_return_df



def stochastic_oscillator_strat(commodity_data_df, price_col, overbought_threshold=80, oversold_threshold=20, k = 14, d = 3):
    """The stochastic oscillator is range-bound, meaning it is always between 0 and 100.
       This makes it a useful indicator of overbought and oversold conditions.
       %K is the fast stochastic oscillator, which presents the location of the closing price
       of a stock in relation to the high and low prices of the stock over a period of time.
       %D is the slow stoch oscillator, the three day moving average of %K, smooths %K
       Area above 80 indicates an overbought region, while the area below 20 is considered an oversold
       region. Sell signal is given when the oscillator is above 80 and then crosses back below 80.
       Buy signal is given when the oscillator is below 20 and then crosses back above 20.
       80 and 20 are the most common levels used but can be adjusted as needed.
       Sell signal occurs when a decreasing %K line crosses below the %D line in the overbought region
       Buy signal occurs when an increasing %K line crosses above the %D line in the oversold region
       returns oscillator_df, origional data plus new columns for %K, %D, Position, market return, and
       strategy return"""

    oscillator_df = commodity_data_df.copy()
    oscillator_df['%K'] = ((oscillator_df[price_col] - oscillator_df[price_col].rolling(k).min()) / (oscillator_df[price_col].rolling(k).max() - oscillator_df[price_col].rolling(k).min())) * 100
    oscillator_df['%D'] = oscillator_df['%K'].rolling(d).mean()
    oscillator_df['Position'] = np.where((oscillator_df['%K'] > oversold_threshold) & (oscillator_df['%K'].shift(1) < oversold_threshold), 1, 0)
    oscillator_df['Position'] = np.where((oscillator_df['%K'] < oversold_threshold) & (oscillator_df['%D'] < oversold_threshold) & (oscillator_df['%K'] > oscillator_df['%D']) & (oscillator_df['%K'] > oscillator_df['%K'].shift(1)), 1, oscillator_df['Position'])
    oscillator_df['Position'] = np.where((oscillator_df['%K'] < overbought_threshold) & (oscillator_df['%K'].shift(1) > overbought_threshold), -1, oscillator_df['Position'])
    oscillator_df['Position'] = np.where((oscillator_df['%K'] > overbought_threshold) & (oscillator_df['%D'] > overbought_threshold) & (oscillator_df['%K'] < oscillator_df['%D']) & (oscillator_df['%K'] < oscillator_df['%K'].shift(1)), -1, oscillator_df['Position'])

    clean_return_df = pd.DataFrame()
    clean_return_df['Date'] = oscillator_df['Date']
    clean_return_df[price_col] = oscillator_df[price_col]
    clean_return_df[price_col+' Position'] = oscillator_df['Position']

    return clean_return_df

index_data_df = pd.read_excel("Cleaned_Data_stripped_weekly.xlsx")
index_data_df = index_data_df.fillna(method='bfill')

fwd_returns_cols = []
strategy_tr_cols = []
pos_returns_cols = []
position_col = []
for col in index_data_df.columns[1:]:
    index_data_df[col+" Position"] = MACD_strat(index_data_df,col)[col+" Position"]
    index_data_df[col+" Daily Return"] = index_data_df[col].pct_change()
    index_data_df[col+" FWD Daily Return"] = np.nan
    index_data_df[col+" FWD Daily Return"].iloc[:-1] = index_data_df[col+" Daily Return"].iloc[1:]
    bb_df = Back_Tester(index_data_df, col+' FWD Daily Return', col+' Position')
    index_data_df[col+" Position Scaled Return"] = bb_df['Position Scaled Return']
    index_data_df[col+" Strategy Total Return"] = bb_df['Strategy Total Return']
    # bb_
    # index_data_df
    # plt.plot(bb_df['Date'],bb_df['Strategy Total Return'])
    # plt.show()
    fwd_returns_cols.append(col+" FWD Daily Return")
    strategy_tr_cols.append(col+" Strategy Total Return")
    pos_returns_cols.append(col+" Position Scaled Return")
    position_col.append(col+" Position")


position_col

index_data_df = index_data_df.iloc[1:-1]
# index_data_df[position_col].to_csv("pos.csv")
daily_fwd_returns_scaled = index_data_df[pos_returns_cols]-1
total_counts = []
for i in range(len(daily_fwd_returns_scaled)):
    # print(daily_fwd_returns_scaled.iloc[i])
    # print("-------------------------------------")
    # print(len(daily_fwd_returns_scaled.iloc[i][daily_fwd_returns_scaled.iloc[i]!=0]))
    # print("-------------------------------------")
    total_counts.append(len(daily_fwd_returns_scaled.iloc[i][daily_fwd_returns_scaled.iloc[i]!=0]))

print(np.mean(total_counts))
plt.plot(total_counts)
plt.show()
# index_data_df.to_csv('all.csv')
#
index_data_df['Portfolio TR'] = index_data_df[strategy_tr_cols].mean(axis=1)
# print(index_data_df['Portfolio TR'])
plt.plot(index_data_df['Portfolio TR'])
plt.show()
# index_data_df.to_csv("xx.csv")
# plt.bar(strategy_tr_cols,index_data_df[strategy_tr_cols].iloc[-1])
# plt.show()
# index_data_df[strategy_tr_cols].to_csv("exam.csv")
# index_data_df[strategy_tr_cols].plot()
# # index_data_df[strategy_tr_cols].mean().plot()
# plt.show()
